import React, {Component} from 'react';

class Form extends Component
{
	constructor(props) {
		super(props);
		this.attachToForm = this.attachToForm.bind(this);
		this.detachFromForm = this.detachFromForm.bind(this);
		this.state = {
			isSubmitting:false,
			isValid: true
		}
	}
	componentWillMount() {
		this.model = {};
		this.inputs = {};
		this.childrens = null;
		this.registerInputs();
	}

	componentDidMount()
	{
		//this.validateForm();	
	}

	registerInputs(children)
	{
		this.childrens = React.Children.map(this.props.children, child => {
			if(child.props.name){

				return React.cloneElement(child, {
					attachToForm:this.attachToForm,
					detachFromForm:this.detachFromForm
				});
			}else{
				return React.cloneElement(child);
			}
			
		});
	}

	updateModel()
	{
		Object.keys(this.inputs).forEach(name => {
			this.model[name] = this.inputs[name].state.value;
		});
	}

	submit(ev)
	{
		ev.preventDefault();
		if(this.state.isSubmitting) return;
		this.updateModel();
		this.setState({
			isSubmitting:true
		});
		setTimeout(() => {
			this.setState({
				isSubmitting:false
			});
		}, 1500)
		console.log(this.model);
	}

	attachToForm(component) {

	    this.inputs[component.props.name] = component;
    
	    // We add the value from the component to our model, using the
	    // name of the component as the key. This ensures that we
	    // grab the initial value of the input
	    this.model[component.props.name] = component.state.value;
	}
	  
	  // We want to remove the input component from the inputs map
	detachFromForm(component) {
	    delete this.inputs[component.props.name];
	    // We of course have to delete the model property
	    // if the component is removed
	    delete this.model[component.props.name];
	}

	render()
	{
		return(
			<form onSubmit={this.submit.bind(this)}>
		        {this.childrens}
		        {!this.state.isSubmitting ? 
		        <button 
		        	type="submit"
		        >
		        	Submit
		        </button>
		        : <div>Submitting</div>}
		    </form>
		);
	}
}

export default Form;