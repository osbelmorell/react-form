import React, {Component} from 'react';

class Input extends Component
{

	constructor(props) {
		super(props);
		this.state = {
			value: this.props.value
		}
	}

	componentWillMount()
	{
		
		// If we use the required prop we add a validation rule
	    // that ensures there is a value. The input
	    // should not be valid with empty value
	    if (this.props.required) {
	      //this.props.validations = this.props.validations ? this.props.validations + ',' : '';
	      //this.props.validations += 'isValue';
	    }
	    this.props.attachToForm(this);
	}

	componentWillUnmount() 
	{
		this.props.detachFromForm(this);	
	}

	setValue(val)
	{
		this.setState({
			value:val
		}, () => {
			this.props.validate(this);
		});
	}

	render()
	{
		console.log(this.state.value);
		return(
			<div>
				{this.props.label && <label htmlFor={this.props.id}>{this.props.label}</label>}
				<input 
					type="text" 
					name={this.props.name}
					value={this.state.value}
					id={this.props.id}
					onChange={ e => this.setValue(e.currentTarget.value)}
				/>
			</div>
		);
	}
}

Input.defaultProps = {
	value:'',
	id:'',
	name:'',
	label:null,
	validations:''
}

export default Input;